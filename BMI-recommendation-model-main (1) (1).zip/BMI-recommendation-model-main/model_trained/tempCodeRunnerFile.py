# Replace the first column in the original data with the one-hot encoded array
# data.iloc[:, :1] = one_hot_encoded_array